package com.example.SpringBootcampConfigServer2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootcampConfigServer2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootcampConfigServer2Application.class, args);
	}

}
